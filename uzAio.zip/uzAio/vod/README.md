# 视频源扩展 type:101

[比较详细的 视频源扩展](https://github.com/YYDS678/uzVideo-extensions/tree/main/vod/js/eacg.js)

# 请为扩展添加以下注释，用于自动更新 json

```
// 如果扩展加密了要用成对的 //空格ignore 包裹

// ignore

//@name:扩展名称
// 网站主页，只有视频源扩展需要
//@webSite:网站主页
// 版本号纯数字
//@version:1
// 备注，没有的话就不填
//@remark:这是备注
// 加密 id，没有的话就不填
//@codeID:
// 使用的环境变量，没有的话就不填
//@env:
// 是否是AV 1是  0否
//@isAV:0
//是否弃用 1是  0否
//@deprecated:0

// ignore

```
